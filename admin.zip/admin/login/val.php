<?php
 session_start();
include('../config.php');
if(isset($_POST['login'])){
     
    $email = $_POST["email"];
    $password = $_POST["password"];
    $result =mysqli_query($con,"SELECT * FROM admin where  email ='$email' ");
      $i=0;
    while($user = mysqli_fetch_array($result)){  
        if(($user['email'] == $email) && 
            ($user['password'] == $password)) {
                $_SESSION['user'] = $user['id'];
                header('location: ../index');
        }
        else {
            header('location: login');
            $_SESSION['message']="error ";
            die;
        }
        $i++;
    }
    if($i==0){
        header('location: login');
            $_SESSION['message']="error ";
            die;  
    }

}
   

 
?>