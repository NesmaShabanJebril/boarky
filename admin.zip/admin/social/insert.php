<?php
include('../config.php');
if(isset($_POST['add'])){
$name = $_POST['name'];
$link = $_POST['link'];
$insert = "INSERT INTO social (`name`,`link`) VALUES ('$name','$link')";
mysqli_query($con , $insert); 




header('Location: index');
exit;

}
?>