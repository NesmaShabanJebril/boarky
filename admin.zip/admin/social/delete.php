<?php
include('../config.php');
 $id = $_GET['id'];
 mysqli_query($con, "DELETE FROM social WHERE id=$id");

 header('location: index');
 exit;
?>