<?php
include('../config.php');
if(isset($_POST['update'])){
$id = $_POST['id'];
$name = $_POST['name'];
$link = $_POST['link'];
$update = "UPDATE  social SET  name='$name'  ,link='$link'  WHERE id=$id ";
mysqli_query($con , $update); 


header('Location: index');
exit;

}
?>