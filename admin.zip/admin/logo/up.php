<?php
include('../config.php');
if(isset($_POST['update'])){
$id = $_POST['id'];
$oldfile = $_POST['old'];
$image_name = addslashes($_FILES['image']['name']);
if($image_name!="") {
    $image_up = 'img/'.$image_name;
    $image_location = $_FILES['image']['tmp_name'];
    move_uploaded_file($image_location,'../../img/'.$image_name);
} else {
$image_up = $oldfile;
}
$update = "UPDATE  logo SET  img='$image_up'  WHERE id=$id ";
mysqli_query($con , $update); 


header('Location: index');
exit;

}
?>