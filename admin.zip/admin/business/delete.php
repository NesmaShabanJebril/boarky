<?php
include('../config.php');
 $id = $_GET['id'];
 mysqli_query($con, "DELETE FROM business WHERE id=$id");

 header('location: index');
 exit;
?>