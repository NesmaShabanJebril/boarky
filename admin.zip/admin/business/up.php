<?php
include('../config.php');
if(isset($_POST['update'])){
$id = $_POST['id'];
$name = $_POST['name'];
$type = $_POST['type'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$update = "UPDATE  business SET  `name`='$name', `type`='$type', `address`='$address', `phone`='$phone' WHERE id=$id ";
mysqli_query($con , $update); 


header('Location: index');
exit;

}
?>