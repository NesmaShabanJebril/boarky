<?php
include('../config.php');
if(isset($_POST['add'])){
$name = $_POST['name'];
$type = $_POST['type'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$insert = "INSERT INTO business (`name`,`type`,`address`,`phone`) VALUES ('$name','$type','$address','$phone')";
mysqli_query($con , $insert); 




header('Location: index');
exit;

}
?>