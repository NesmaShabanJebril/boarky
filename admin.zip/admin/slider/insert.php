<?php
include('../config.php');
if(isset($_POST['add'])){
    $image_name = addslashes($_FILES['image']['name']);
    $image_up = 'img/'.$image_name;
    $image_location = $_FILES['image']['tmp_name'];
$insert = "INSERT INTO slider (`img`) VALUES ('$image_up')";
mysqli_query($con , $insert); 
move_uploaded_file($image_location,'../../img/'.$image_name);
if(move_uploaded_file($image_location,'../../img/'.$image_name)){
    echo "<script>alert('uploaded')</script>";
}
else{
    echo "<script>alert('error')</script>";
}
header('Location: index');
exit;

}
?>