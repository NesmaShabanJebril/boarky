<?php
include('../config.php');
 $id = $_GET['id'];
 mysqli_query($con, "DELETE FROM slider WHERE id=$id");

 header('location: index');
 exit;
?>