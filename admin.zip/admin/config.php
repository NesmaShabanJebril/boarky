<?php
$con= mysqli_connect('localhost','buarkibuarki','buarkibuarki','buarki');
/* if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
  }
  echo "Connected successfully"; */
  

?>