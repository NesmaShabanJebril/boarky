<?php
 session_start();
$_SESSION['user'] ;
 if($_SESSION['user']){
include('../config.php');
$user=$_SESSION['user'];
$up = mysqli_query($con,"select * from admin where id= $user");
$data = mysqli_fetch_array($up);
   $logo1 = mysqli_query($con, "SELECT * FROM logo");
               $logo = mysqli_fetch_array($logo1);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  
  <link href="../style_ar.css" rel="stylesheet">
  <link href="../css/style.css" rel="stylesheet">

 <style>

  </style>

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center justify-content-between">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index" class=" d-flex align-items-center ms-5">
        <img src="../<?php echo $logo['img']?>" alt="" width="80px" height="60px" class="ms-5">
        <span class="d-none d-lg-block"></span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    
    <nav class="header-nav ">
      <ul class="d-flex align-items-center">

      
        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">
            <?php
             $result = mysqli_query($con, "SELECT * FROM user where  `status`='0'");
             $i=0;
              while($row = mysqli_fetch_array($result)){
                  $i++;
              }
              echo $i;
          ?>
            </span>
          </a><!-- End Notification Icon -->
           
          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
           
           <?php
             $result = mysqli_query($con, "SELECT * FROM user where  `status`='0'");
             $i=0;
              while($row = mysqli_fetch_array($result)){
              echo "
                  <li class='notification-item'>
              <i class='bi bi-check-circle text-success'></i>
              <a href='user/new'>
                <h4>$row[name] </h4>
                <p>مستخدم جديد</p>
              </div>
            </li>
              ";
                  
                  
              }
             
          ?>
       

            <li>
              <hr class="dropdown-divider">
            </li>

     
          </ul> 

        </li><!-- End Notification Nav -->

   

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <!--img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle"-->
            <span class="d-none d-md-block dropdown-toggle px-2"> 
            <?php
         echo  $data['name'];
           ?></span>
          </a><!-- End Profile Iamge Icon -->

     <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
           
           

            <!--li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li-->

     

            <li>
              <a class="dropdown-item d-flex align-items-center" href="admins/logout">
                <i class="bi bi-box-arrow-right px-2"></i>
                <span> خروج</span>
              </a>
            </li>

          </ul> 
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
     
        <a class="nav-link collapsed" href="index">

          <i class="bi bi-grid px-2"></i>
          <span >  الرئيسية   </span>
        </a>
      </li><!-- End Dashboard Nav -->
     
      <li class="nav-item">
   
        <a class="nav-link collapsed" href="admins/index">
                  <i class="bi bi-file-earmark-person px-2"></i>
          <span >  الادمن   </span>
        </a>
      </li><!-- End Dashboard Nav -->
   
      <li class="nav-item">
   
   <a class="nav-link collapsed" href="about/index">
            <i class="bi bi-person-circle px-2"></i>
     <span >  نبذة عنا   </span>
   </a>
 </li><!-- End Dashboard Nav -->
 
 <li class="nav-item">
   
   <a class="nav-link collapsed" href="tree/index">
             <i class="bi bi-snow2 px-2"></i>
     <span >  شجرة العائلة  </span>
   </a>
 </li><!-- End Dashboard Nav -->
 <li class="nav-item">  
   <a class="nav-link collapsed" href="user/index">
             <i class="bi bi-people-fill px-2"></i>
     <span >  المستخدمين </span>
   </a>
 </li>
 <li class="nav-item">  
   <a class="nav-link collapsed" href="user/new">
              <i class="bi bi-person-plus-fill px-2"></i>
     <span >   المستخدمين الجدد</span>
   </a>
 </li>
 <li class="nav-item">  
   <a class="nav-link collapsed" href="diwan/index">
              <i class="bi bi-house-door-fill px-2"></i>
     <span >    الدواوين</span>
   </a>
 </li> 
 <li class="nav-item">  
   <a class="nav-link collapsed" href="box/index">
            <i class="bi bi-box"></i>
     <span >    انجازات الصندوق</span>
   </a>
 </li>
 <li class="nav-item">  
   <a class="nav-link collapsed" href="box/user_box">
           <i class="bi bi-person-lines-fill px-2"></i>
     <span >    المساهمين بالصندوق</span>
   </a>
 </li> 
 
 <li class="nav-item">  
   <a class="nav-link collapsed" href="business/index">
              <i class="bi bi-award px-2"></i>
     <span >  الدليل التجاري</span>
   </a>
 </li> 
 <li class="nav-item">  
   <a class="nav-link collapsed" href="gallary/index">
          <i class="bi bi-image px-2"></i>
     <span >   معرض الصور</span>
   </a>
 </li>
 <li class="nav-item">  
   <a class="nav-link collapsed" href="news/index">
              <i class="bi bi-receipt px-2"></i>
     <span >    اخبار العائلة</span>
   </a>
 </li>
 <li class="nav-item">  
   <a class="nav-link collapsed" href="contact/index">
            <i class="bi bi-phone px-2"></i>
     <span >      تواصل معانا</span>
   </a>
 </li>
 <li class="nav-item">  
   <a class="nav-link collapsed" href="social/index">
            <i class="bi bi-server px-2"></i>
     <span >     مواقع التواصل</span>
   </a>
 </li>
  <li class="nav-item">  
   <a class="nav-link collapsed" href="logo/index">
         <i class="bi bi-image px-2"></i>
     <span >    صورة اللوجو</span>
   </a>
 </li>
   <li class="nav-item">  
   <a class="nav-link collapsed" href="slider/index">
         <i class="bi bi-image px-2"></i>
     <span >    صور السليدر</span>
   </a>
 </li>
    </ul>

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>الرئيسية</h1>
     
    </div><!-- End Page Title -->

    <section class="section dashboard">
    <br>

        <!-- Left side columns -->
        
          <div class="row">

            <!-- Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="admins/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-file-earmark-person"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                        الادمن </h6>
                    </div>
                  </div>
                </div>
                     </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="about/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-person-circle"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                        نبذة عنا </h6>
                    </div>
                  </div>
                </div>
             </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="tree/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-snow2"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                      شجرة العائلة </h6>
                    </div>
                  </div>
                </div>
                 </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="user/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-people-fill"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                      المستخدمين</h6>
                    </div>
                  </div>
                </div>
                 </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="user/new" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-person-plus-fill "></i>
                    </div>
                    <div class="px-3">
                      <h6>
                      المستخدمين الجدد </h6>
                    </div>
                  </div>
                </div>
                </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="diwan/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-house-door-fill"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                      الدواوين </h6>
                    </div>
                  </div>
                </div>
              </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="box/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-box"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                      انجازات الصندوق </h6>
                    </div>
                  </div>
                </div>
                </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="box/user_box" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-person-lines-fill"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                      المساهمين بالصندوق </h6>
                    </div>
                  </div>
                </div>
              </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="business/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-award"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                      الدليل التجاري </h6>
                    </div>
                  </div>
                </div>
                  </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="gallary/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-image"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                      معرض الصور </h6>
                    </div>
                  </div>
                </div>
                </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="news/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-receipt"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                      اخبار العائلة </h6>
                    </div>
                  </div>
                </div>
                </a>
            </div><!-- End Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <a href="contact/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-server"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                      مواقع التواصل </h6>
                    </div>
                  </div>
                </div>
      </a>
            </div><!-- End Sales Card -->
              <div class="col-xxl-4 col-md-6">
              <a href="logo/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-image"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                       صورة اللوجو </h6>
                    </div>
                  </div>
                </div>
                </a>
            </div><!-- End Sales Card -->
                          <div class="col-xxl-4 col-md-6">
              <a href="slider/index" class="card info-card sales-card">
                <br>
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-image"></i>
                    </div>
                    <div class="px-3">
                      <h6>
                       صور السليدر </h6>
                    </div>
                  </div>
                </div>
                </a>
            </div><!-- End Sales Card -->
      <!-- Sales Card -->
  
          </div>
      
    </section>

  </main><!-- End #main -->

 
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

   <!-- Vendor JS Files -->
   <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
   <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
   <script src="assets/vendor/chart.js/chart.umd.js"></script>
   <script src="assets/vendor/echarts/echarts.min.js"></script>
   <script src="assets/vendor/quill/quill.js"></script>
   <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
   <script src="assets/vendor/tinymce/tinymce.min.js"></script>
   <script src="assets/vendor/php-email-form/validate.js"></script>
 
   <!-- Template Main JS File -->
   <script src="assets/js/main.js"></script>
 


  </body>

</html>
<?php 
 }
else{
        header('location: login/login');
            $_SESSION['message']="login ";
            die;  
    }
    ?>