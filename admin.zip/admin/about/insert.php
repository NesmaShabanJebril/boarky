<?php
include('../config.php');
if(isset($_POST['add'])){
$about = $_POST['about'];
$insert = "INSERT INTO about (`about`) VALUES ('$about')";
mysqli_query($con , $insert); 




header('Location: index');
exit;

}
?>