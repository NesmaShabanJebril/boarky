<?php
 session_start();
 if($_SESSION['user']){
include "../header.php" ?>

  
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>نبذة عنا </h1>
      <br>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">نبذة عنا</h5>

              <a href="add" class="btn m-btn">اضافة نبذة </a>
              <br><br>
              <!-- Table with stripped rows -->
              <div class="table-responsive">

              <table class="table datatable border table-bordered  " >
                <thead>
                  <tr>
                    <th>
                    id
                    </th>
                    <th>
                    نذة
                    </th>
                    
                    <th>تعديل</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                  include('../config.php');
                  $result = mysqli_query($con, "SELECT * FROM about");
                  while($row = mysqli_fetch_array($result)){
                  echo "
                  <tr>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[id]</td>
                    <td  style='border-bottom: 1px solid #e9ecef'><br> $row[about]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>
                    <a href='update.php?id=$row[id]' class='btn m-btn'>تعديل</a>
                    <a href='delete.php?id=$row[id] ' class='btn btn-danger'>حذف</a>                
                     </td>
                    
                  </tr>
                 ";}
                 ?>
                </tbody>
              </table>
                  </div>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- End #main -->
  <?php include "../footer.php" ;
 }
 else{
  header('location: ../login/login.php');
            $_SESSION['message']="login ";
            die; 
 }
  ?>
