<?php
include('../config.php');
if(isset($_POST['update'])){
$id = $_POST['id'];
$about = $_POST['about'];
$update = "UPDATE  about SET  about='$about'  WHERE id=$id ";
mysqli_query($con , $update); 


header('Location: index');
exit;

}
?>