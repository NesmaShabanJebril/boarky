<?php
include('../config.php');
 $id = $_GET['id'];
 mysqli_query($con, "DELETE FROM about WHERE id=$id");

 header('location: index');
 exit;
?>