<?php
include('../config.php');
 $id = $_GET['id'];
 mysqli_query($con, "DELETE FROM gallary WHERE id=$id");

 header('location: index');
 exit;
?>