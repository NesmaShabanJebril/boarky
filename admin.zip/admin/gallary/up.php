<?php
include('../config.php');
if(isset($_POST['update'])){
$id = $_POST['id'];
$name = $_POST['name'];
    $details = $_POST['details'];
       $link = $_POST['link'];
$oldfile = $_POST['old'];
$image_name = addslashes($_FILES['image']['name']);
if($image_name!="") {
    $image_up = 'img/'.$image_name;
    $image_location = $_FILES['image']['tmp_name'];
    move_uploaded_file($image_location,'../../img/'.$image_name);
} else {
$image_up = $oldfile;
}
$update = "UPDATE  gallary SET name='$name', img='$image_up', details='$details' ,link='$link'  WHERE id=$id ";
mysqli_query($con , $update); 


header('Location: index');
exit;

}
?>