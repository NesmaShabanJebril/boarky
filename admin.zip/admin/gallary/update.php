<?php
 session_start();
 if($_SESSION['user']){
include "../header.php" ?>

  <main id="main" class="main">

        <div class="pagetitle">
          <h1> تعديل </h1>

        </div><!-- End Page Title -->
        <br>
        <section class="section">
  

      <div class="card">
        <div class="card-body">
          <h5 class="card-title"></h5>
          <?php
            include('../config.php');
            $id = $_GET['id'];
            $result = mysqli_query($con,"select * from gallary where id= $id");
            $row = mysqli_fetch_array($result);
            ?>

          <!-- Vertical Form -->
          <form class="row g-3"   action="up.php" method="post"  enctype="multipart/form-data">
          <input type="text" class="form-control" name="id" value="<?php echo $row['id']?>" style="display:none">

          <div class="col-12">
                  <label  class="form-label">الصورة</label>    
                    <input class="form-control" type="file"  name="image" >
                    <input type="text" name="old" value="<?php echo $row['img']?>" style="display:none"> 
             <br>   
          <img src="../../<?php echo $row['img']?>" width="100">  
          </div>
          <div class="col-12">
              <label class="form-label">المناسبة </label>
              <input type="text" class="form-control" name="name" value="<?php echo $row['name']?>" >
            </div>
               <div class="col-12">
                  <label class="form-label"> الوصف </label>
                  <input type="text" class="form-control" name="details" value="<?php echo $row['details']?>">
                </div>
                 <div class="col-12">
                  <label class="form-label"> الرابط </label>
                  <input type="text" class="form-control" name="link" value="<?php echo $row['link']?>">
                </div>
            <div class="text-center">
              <button type="submit" class="btn m-btn" name="update">تعديل </button>
            </div>
            <br>
          </form><!-- Vertical Form -->

        </div>
      </div>


    </section>

</main><!-- End #main -->

  <!-- End #main -->
  <?php include "../footer.php" ;
 }
 else{
  header('location: ../login/login.php');
            $_SESSION['message']="login ";
            die; 
 }
  ?>