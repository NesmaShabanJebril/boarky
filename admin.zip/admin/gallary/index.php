<?php
 session_start();
 if($_SESSION['user']){
include "../header.php" ?>

  
  <main id="main" class="main">

    <div class="pagetitle">
      <h1> معرض صور  العائلة </h1>
      <br>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title" >  معرض  صور  العائلة </h5>

              <a href="add" class="btn m-btn">اضافة صورة     </a>
              <br><br>
              <!-- Table with stripped rows -->
              <div class="table-responsive">
              <table class="table datatable border table-bordered  " >
                <thead>
                  <tr>
                    <th>
                    id
                    </th>
                    <th>
                    الصورة
                    </th>
                    <th>
                    المناسبة
                    </th>
                      <th>
                    الوصف
                    </th>
                       <th>
                    الرابط
                    </th>
                    <th>تعديل</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                include('../config.php');
                $result = mysqli_query($con, "SELECT * FROM gallary");
                while($row = mysqli_fetch_array($result)){
                echo "
                  <tr>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[id]</td>
                    <td  style='border-bottom: 1px solid #e9ecef'><a href='https://buarki-kw.net/$row[img]' target='_blank'><img src='../../$row[img]' width='200'></a></td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[name]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[details]</td>
                       <td style='border-bottom: 1px solid #e9ecef'><br>$row[link]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>
                    <a href='update.php?id=$row[id]' class='btn m-btn'>تعديل</a>
                    <a href='delete.php?id=$row[id] ' class='btn btn-danger'>حذف</a>                
                     </td>
                    
                  </tr>
                 ";}
                 ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->
                </div>
            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- End #main -->
  <?php include "../footer.php" ;
 }
 else{
  header('location: ../login/login.php');
            $_SESSION['message']="login ";
            die; 
 }
  ?>
