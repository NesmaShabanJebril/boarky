<?php
include('../config.php');
if(isset($_POST['add'])){
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$insert = "INSERT INTO admin (`name`,`email`, `password`) VALUES ('$name','$email','$password')";
mysqli_query($con , $insert); 

header('Location: index');
exit;

}
?>