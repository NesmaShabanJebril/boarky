<?php
include('../config.php');
if(isset($_POST['update'])){
$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

$update = "UPDATE  admin SET  name='$name' , email='$email' , password='$password'  WHERE id=$id ";
mysqli_query($con , $update); 


header('Location: index');
exit;

}
?>