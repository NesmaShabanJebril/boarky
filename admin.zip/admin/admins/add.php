<?php
 session_start();
 if($_SESSION['user']){
include "../header.php" ?>

  
  <main id="main" class="main">

    <div class="pagetitle">
      <h1> اضافة ادمن  </h1>
   
    </div><!-- End Page Title -->
    <section class="section">
      

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">  اضافة ادمن </h5>

              <!-- Vertical Form -->
              <form class="row g-3"   action="insert.php" method="post"  enctype="multipart/form-data">
                
              <input type="text" class="form-control" name="user" value="<?php echo $user?>" style="display:none">
              <div class="col-12">
                  <label class="form-label">الأسم </label>
                  <input type="text" class="form-control" name="name">
                </div>
                
                <div class="col-12">
                  <label  class="form-label">الايميل</label>    
                    <input class="form-control" type="text"  name="email">
                </div>
               
               
                <div class="col-12">
                  <label  class="form-label">كلمه المرور</label>    
                    <input class="form-control" type="text"  name="password">
                </div>
                         </div>
           
                <div class="text-center">
                  <button type="submit" class="btn m-btn" name="add">اضافة</button>
                </div>
                <br><br>
              </form><!-- Vertical Form -->

            </div>
          </div>


    </section>

  </main><!-- End #main -->

  <!-- End #main -->

  <?php include "../footer.php" ;
 }
 else{
  header('location: ../login/login.php');
            $_SESSION['message']="login ";
            die; 
 }
  ?>