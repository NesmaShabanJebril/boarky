<?php
include('../config.php');
 $id = $_GET['id'];
 mysqli_query($con, "DELETE FROM admin WHERE id=$id");

 header('location: index');
 exit;
?>