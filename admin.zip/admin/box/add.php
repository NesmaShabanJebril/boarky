<?php
 session_start();
 if($_SESSION['user']){
include "../header.php" ?>
  
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>  انجازات صندوق المساهمين  </h1>
   <br>
    </div><!-- End Page Title -->
    <section class="section">
      

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">  اضافة انجاز </h5>

              <!-- Vertical Form -->
              <form class="row g-3"   action="insert.php" method="post"  enctype="multipart/form-data">
                
              <div class="col-12">
                  <label class="form-label">انجاز صندوق المساهمين  </label>
                  <input type="text" class="form-control" name="box">
                </div>
              
                <div class="text-center">
                  <button type="submit" class="btn m-btn" name="add">اضافة</button>
                </div>
                <br><br>
              </form><!-- Vertical Form -->

            </div>
          </div>


    </section>

  </main><!-- End #main -->

  <!-- End #main -->

  <?php include "../footer.php" ;
 }
 else{
  header('location: ../login/login.php');
            $_SESSION['message']="login ";
            die; 
 }
  ?>