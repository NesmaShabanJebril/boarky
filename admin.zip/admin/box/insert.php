<?php
include('../config.php');
if(isset($_POST['add'])){
$box = $_POST['box'];
$insert = "INSERT INTO `box` (`box`) VALUES ('$box')";
mysqli_query($con , $insert); 




header('Location: index');
exit;

}
?>