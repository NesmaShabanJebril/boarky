<?php
include('../config.php');
 $id = $_GET['id'];
 mysqli_query($con, "DELETE FROM `user_box` WHERE id=$id");

 header('location: user_box');
 exit;
?>