<?php
include('../config.php');
if(isset($_POST['update'])){
$id = $_POST['id'];
$box = $_POST['box'];
$update = "UPDATE  `box` SET  `box`='$box'  WHERE id=$id ";
mysqli_query($con , $update); 


header('Location: index');
exit;

}
?>