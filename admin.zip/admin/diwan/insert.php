<?php
include('../config.php');
if(isset($_POST['add'])){
    $city = $_POST['city'];
    $address = $_POST['address'];
    $owner = $_POST['owner'];
    $phone = $_POST['phone'];
    $time = $_POST['time']; 
    $location = $_POST['location'];  
 
$insert = "INSERT INTO diwan (`city`,`address`,`owner`,`phone`,`time`,`location`) VALUES ('$city','$address','$owner','$phone','$time','$location')";
mysqli_query($con , $insert); 

header('Location: index');
exit;

}
?>