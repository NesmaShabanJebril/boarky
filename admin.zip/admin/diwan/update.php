<?php
 session_start();
 if($_SESSION['user']){
include "../header.php" ?>

  <main id="main" class="main">

        <div class="pagetitle">
          <h1> تعديل </h1>

        </div><!-- End Page Title -->
        <br>
        <section class="section">
  

      <div class="card">
        <div class="card-body">
          <h5 class="card-title"></h5>
          <?php
            include('../config.php');
            $id = $_GET['id'];
            $result = mysqli_query($con,"select * from diwan where id= $id");
            $row = mysqli_fetch_array($result);
            ?>

          <!-- Vertical Form -->
          <form class="row g-3"   action="up.php" method="post"  enctype="multipart/form-data">
          <input type="text" class="form-control" name="id" value="<?php echo $row['id']?>" style="display:none">
          <div class="col-12">
              <label class="form-label">المنطقة </label>
              <input type="text" class="form-control" name="city" value="<?php echo $row['city']?>" >
            </div>
            <div class="col-12">
              <label class="form-label">العنوان </label>
              <input type="text" class="form-control" name="address" value="<?php echo $row['address']?>" >
            </div>
            <div class="col-12">
              <label class="form-label">المسئول </label>
              <input type="text" class="form-control" name="owner" value="<?php echo $row['owner']?>" >
            </div>
            <div class="col-12">
              <label class="form-label">الهاتف </label>
              <input type="text" class="form-control" name="phone" value="<?php echo $row['phone']?>" >
            </div>
            <div class="col-12">
              <label class="form-label">التوقيت </label>
              <input type="text" class="form-control" name="time" value="<?php echo $row['time']?>" >
            </div>
            <div class="col-12">
              <label class="form-label">الموقع علي الخريطة </label>
              <input type="text" class="form-control" name="location" value="<?php echo $row['location']?>" >
            </div>
            <div class="text-center">
              <button type="submit" class="btn m-btn" name="update">تعديل </button>
            </div>
            <br>
          </form><!-- Vertical Form -->

        </div>
      </div>


    </section>

</main><!-- End #main -->

  <!-- End #main -->
  <?php include "../footer.php" ;
 }
 else{
  header('location: ../login/login.php');
            $_SESSION['message']="login ";
            die; 
 }
  ?>