<?php
 session_start();
 if($_SESSION['user']){
include "../header.php" ?>

  
  <main id="main" class="main">

    <div class="pagetitle">
      <h1> دواوين  العائلة </h1>
      <br>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title" >  دواوين  العائلة </h5>

              <a href="add" class="btn m-btn">اضافة دواوين  العائلة  </a>
              <br><br>
              <!-- Table with stripped rows -->
              <div class="table-responsive">
              <table class="table datatable border table-bordered  " >
                <thead>
                  <tr>
                    <th>
                    id
                    </th>
                    <th>
                    المنطقه
                    </th>
                    <th>
                    العنوان
                    </th>
                    <th>
                    المسئول
                    </th>
                    <th>
                    الهاتف
                    </th>
                    <th>
                    التوقيت
                    </th>
                    <th>اللوكيشن</th>
                    <th>تعديل</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                  include('../config.php');
                  $result = mysqli_query($con, "SELECT * FROM diwan");
                  while($row = mysqli_fetch_array($result)){
                  echo "
                  <tr>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[id]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[city]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[address]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[owner]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[phone]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[time]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br><a href='$row[location]' target='_blank'>الموقع علي الخريطة</a></td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>
                    <a href='update.php?id=$row[id]' class='btn m-btn'>تعديل</a>
                    <a href='delete.php?id=$row[id] ' class='btn btn-danger'>حذف</a>                
                     </td>
                    
                  </tr>
                 ";}
                 ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->
                  </div>
            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- End #main -->
  <?php include "../footer.php" ;
 }
 else{
  header('location: ../login/login.php');
            $_SESSION['message']="login ";
            die; 
 }
  ?>
