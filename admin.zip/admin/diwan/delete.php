<?php
include('../config.php');
 $id = $_GET['id'];
 mysqli_query($con, "DELETE FROM diwan WHERE id=$id");

 header('location: index');
 exit;
?>