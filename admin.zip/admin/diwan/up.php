<?php
include('../config.php');
if(isset($_POST['update'])){
$id = $_POST['id'];
$city = $_POST['city'];
$address = $_POST['address'];
$owner = $_POST['owner'];
$phone = $_POST['phone'];
$time = $_POST['time']; 
$location = $_POST['location']; 
$update = "UPDATE  diwan SET  city='$city' ,`address`='$address' ,`owner`='$owner',`phone`='$phone' ,`time`='$time',`location`='$location'  WHERE id=$id ";
mysqli_query($con , $update); 


header('Location: index');
exit;

}
?>