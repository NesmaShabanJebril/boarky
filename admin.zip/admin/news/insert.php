<?php
include('../config.php');
if(isset($_POST['add'])){
    $name = $_POST['name'];
    $details = $_POST['details'];
    $link = $_POST['link'];
    $image_name = addslashes($_FILES['image']['name']);
    $image_up = 'img/'.$image_name;
    $image_location = $_FILES['image']['tmp_name'];
$insert = "INSERT INTO news (`img`,`name`,`details`,`link`) VALUES ('$image_up','$name','$details','$link')";
mysqli_query($con , $insert); 
move_uploaded_file($image_location,'../../img/'.$image_name);
if(move_uploaded_file($image_location,'../../img/'.$image_name)){
    echo "<script>alert('uploaded')</script>";
}
else{
    echo "<script>alert('error')</script>";
}
header('Location: index');
exit;

}
?>