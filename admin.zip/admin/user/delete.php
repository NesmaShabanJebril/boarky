<?php
include('../config.php');
 $id = $_GET['id'];
 $update = "UPDATE  user SET  `status`='0'  WHERE id=$id ";
 mysqli_query($con,$update);
 header('location: index');
 exit;
?>