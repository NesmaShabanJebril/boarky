<?php
include('../config.php');
 $id = $_GET['id'];
 $update = "UPDATE  user SET  `status`='1'  WHERE id=$id ";
 mysqli_query($con,$update);
 header('location: new');
 exit;
?>