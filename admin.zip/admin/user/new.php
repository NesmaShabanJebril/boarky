<?php
 session_start();
 if($_SESSION['user']){
include "../header.php" ?>

  
  <main id="main" class="main">

    <div class="pagetitle">
      <h1> المستخدمين الجدد</h1>
      <br>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title" >  المستخدمين  الجدد </h5>

              <br><br>
              <!-- Table with stripped rows -->
              <table class="table datatable border table-bordered  " >
                <thead>
                  <tr>
                    <th>
                    id
                    </th>
                    <th>
                    الصورة
                    </th>
                    <th>
                    الاسم
                    </th>
                    <th>
                    الايميل
                    </th>
                    <th>
                    الموبايل
                    </th>
                    <th>
                    العنوان
                    </th>
                    <th>تعديل</th>
                  </tr>
                </thead>
                <tbody>
                <?php
      include('../config.php');
      $result = mysqli_query($con, "SELECT * FROM user where `status`='0'");
      while($row = mysqli_fetch_array($result)){
      echo "
                  <tr>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[id]</td>
                    <td  style='border-bottom: 1px solid #e9ecef'><a href='https://buarki-kw.net/$row[img]' target='_blank'><img src='../../$row[img]' width='200'></a></td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[name]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[email]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[phone]</td>
                    <td style='border-bottom: 1px solid #e9ecef'><br>$row[address]</td>

                    <td style='border-bottom: 1px solid #e9ecef'><br>
                    <a href='accept.php?id=$row[id] ' class='btn m-btn'>قبول</a> 
                    <a href='delete1.php?id=$row[id] ' class='btn btn-danger'>حذف</a
                     </td>
                    
                  </tr>
                 ";}
                 ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- End #main -->
  <?php include "../footer.php" ;
 }
 else{
  header('location: ../login/login.php');
            $_SESSION['message']="login ";
            die; 
 }
  ?>
