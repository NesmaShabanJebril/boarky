<?php
 session_start();
 if($_SESSION['user']){
include "../header.php" ?>

  
  <main id="main" class="main">

    <div class="pagetitle">
      <h1> تواصل معانا </h1>
      <br>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"> تواصل معانا</h5>

              <br><br>
              <!-- Table with stripped rows -->
              <div class="table-responsive">

              <table class="table datatable border table-bordered  " >
                <thead>
                  <tr>
                    <th>
                    موبايل
                    </th>
                 
                    <th>
                ايميل
                    </th>
                   
                    <th>
                واتس اب
                    </th>
                 
                    <th>تعديل</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                  include('../config.php');
                  $result = mysqli_query($con, "SELECT * FROM `contact`");
                  while($row = mysqli_fetch_array($result)){
                  echo "
                  <tr>
                    <td  style='border-bottom: 1px solid #e9ecef'><br> $row[phone]</td>
                    <td  style='border-bottom: 1px solid #e9ecef'><br> $row[gmail]</td>
                    <td  style='border-bottom: 1px solid #e9ecef'><br> $row[whatsapp]</td>
                    
                    <td style='border-bottom: 1px solid #e9ecef'><br>
                    <a href='update.php?id=$row[id]' class='btn m-btn'>تعديل</a>
                     </td>
                    
                  </tr>
                 ";}
                 ?>
                </tbody>
              </table>
                  </div>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- End #main -->
  <?php include "../footer.php" ;
 }
 else{
  header('location: ../login/login.php');
            $_SESSION['message']="login ";
            die; 
 }
  ?>
