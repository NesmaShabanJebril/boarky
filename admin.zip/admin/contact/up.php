<?php
include('../config.php');
if(isset($_POST['update'])){
$id = $_POST['id'];
$phone = $_POST['phone'];
$whatsapp = $_POST['whatsapp'];
$gmail = $_POST['gmail'];

$update = "UPDATE  `contact` SET  `phone`='$phone',  `whatsapp`='$whatsapp', `gmail`='$gmail'  WHERE id=$id ";
mysqli_query($con , $update); 


header('Location: index');
exit;

}
?>