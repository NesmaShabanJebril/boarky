
<?php
session_start();
include('../config.php');
if(isset($_POST['add'])){
    $id=$_SESSION['users'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $oldfile = $_POST['old'];
    $image_name = addslashes($_FILES['image']['name']);
    if($image_name!="") {
        $image_up = 'img/'.$image_name;
        $image_location = $_FILES['image']['tmp_name'];
        move_uploaded_file($image_location,'../img/'.$image_name);
    } else {
    $image_up = $oldfile;
    }
    $update = "UPDATE  user SET `name`='$name', `email`='$email',`password`='$password', `phone`='$phone',`address`='$address' ,`img`='$image_up'  WHERE id=$id ";
    mysqli_query($con , $update); 
        $_SESSION['message']="تم تحديث البيانات";
        header('Location: profile');
        exit;
    }

?>
<?php 
include "header.php"; 
$result1 = mysqli_query($con, "SELECT * FROM user where id='$_SESSION[users]'");
 $user = mysqli_fetch_array($result1);
?>
<br><br> <br><br> 


  <main style="background:#043c5a">
    <div class="container">

      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

              <div class="card mb-3 ">

                <div class="card-body">
                <?php 
	
    if(isset($_SESSION['message'])){
      ?>
      <div class="alert alert-success text-center">
        <?php echo $_SESSION['message']; ?>
      </div>
      <?php
      unset($_SESSION['message']);
    }

    ?>
                          <a href="logout" class="btn m-btn w-100">خروج</a>

                  <div class="pt-4 pb-2 text-center">
                    <img src="../<?php echo $user['img']?>" width="200" >
                    <h5 class="card-title text-center pb-0 fs-4"><?php echo $user['name'] ?></h5>
                  </div>
                
              
                  <form class="row g-3 needs-validation" action="profile.php" method="post"  enctype="multipart/form-data" novalidate>
                  <div class="col-12">
                      <label  class="form-label"> الاسم بالكامل</label>
                      <input type="text" name="name" value="<?php echo $user['name'] ?>" class="form-control"  required>
                      <div class="invalid-feedback">من فضلك ادخل  الاسم بالكامل</div>
                    </div>
                    <div class="col-12">
                      <label  class="form-label"> ايميل</label>
                      <input type="email" name="email" value="<?php echo $user['email'] ?>" class="form-control"  required>
                      <div class="invalid-feedback">من فضلك ادخل  الايميل</div>
                    </div>
                    <div class="col-12">
                      <label  class="form-label"> موبايل</label>
                      <input type="text" name="phone" value="<?php echo $user['phone'] ?>" class="form-control"  required>
                      <div class="invalid-feedback">من فضلك ادخل رقم  الموبايل</div>
                    </div>
                    <div class="col-12">
                      <label  class="form-label">العنوان </label>
                      <input type="text" name="address" value="<?php echo $user['address'] ?>" class="form-control"  required>
                      <div class="invalid-feedback">من فضلك ادخل  العنوان</div>
                    </div>
                    <div class="col-12">
                      <label  class="form-label">كلمة المرور</label>
                      <input type="password" name="password" value="<?php echo $user['password'] ?>" class="form-control" id="yourPassword" required>
                      <div class="invalid-feedback">من فضلك ادخل كلمة المرور</div>
                    </div>
                    <div class="col-12">
                  <label  class="form-label">الصورة</label>    
                    <input class="form-control" type="file"  name="image">
                    <input class="form-control" type="text"  name="old" value="<?php echo $user['img'] ?>" hidden>

                </div>
        
                    
                    <div class="col-12">
                      <button class="btn m-btn w-100" type="submit" name="add">تعديل</button>
                    </div>
                  
                  </form>

                </div>
</div>

            </div>
          </div>
        </div>

      </section>

    </div>
  </main><!-- End #main -->


<?php include "footer.php" ?>
