<?php
session_start();
$news="active";
include "header.php" ?>
<br><br> <br><br> 
<div class="container my-5">
        <br><br>
        <h1>
            اخبار عائلة بوعركي
        </h1>
        <br><br>
        <div class="row">
        <?php
        include('../config.php');
        $result = mysqli_query($con, "SELECT * FROM news");
       while($row = mysqli_fetch_array($result)){
        echo "
        <div class='col-md-3 col-sm-6'>
        <div class='card my-5'>
        <a  href='$row[link]' target='_blank'>  <img src='../$row[img]' class='card-img-top' ></a>
          <div class='card-body'>
             <a  href='$row[link]' target='_blank'><h5 class='card-title'> $row[name]</h5></a>
            <p class='card-text'>  $row[details]</p>
          </div>
        </div>
      </div>
        <br><br>";
       }
        ?>
        </div>
        <br><br>

       <br><br> 
 </div>
 <?php include "footer.php" ;

  ?>