<?php 
  include('../config.php');
   $logo1 = mysqli_query($con, "SELECT * FROM logo");
               $logo = mysqli_fetch_array($logo1);
               ?>
               <html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>موقع عائلة بوعركي</title> 
  <link rel="stylesheet" href="../css/all.min.css">
  <script src="../js/all.min.js"></script>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery-3.7.1.min.js"></script>
  <script src="../js/main.js"></script>
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/media.css">
  <style>
    .card-img-top{
     height:200px!important;
    }
    </style>
</head>
<body class="bg-light">
  <nav class="navbar navbar-expand-lg bg-body fixed-top shadow">
   <div class="container-fluid">
      <a class="navbar-brand" href="../index.php"><img src="../<?php echo $logo['img']?>" class="logo"> </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav  mr-auto">
          <li class="nav-item">
            <a class="nav-link "  href="../index">الرئيسية</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo $about ?>"  href="about">نبذة</a>
          </li>
          <li class="nav-item">
            <a class="nav-link  <?php echo $tree?>"  href="tree">شجرة العائلة</a>
          </li>
          <li class="nav-item">
            <a class="nav-link  <?php echo $diwan?>"  href="diwan"> الدواوين</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo $box?>"  href="box"> صندوق المساهمين</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo $business?>"  href="business"> الدليل التجاري</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo $gallary?>"  href="gallary"> معرض الصور</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo $news?>"  href="news"> اخبار</a>
          </li>
          <li class="nav-item">
            <a class="nav-link"  href="contact_us"> تواصل معانا</a>
          </li>
          <li class="nav-item">
            <?php 
            
            if($_SESSION['users']!="0"){
              ?> 
              <a class="nav-link m-btn btn "  href="profile">   البروفايل</a>
              <?php
            }
            else{
            ?>
            <a class="nav-link m-btn btn "  href="register">  تسجيل حساب</a>
          <?php } ?>
          </li>
           <li class="nav-item">
          <?php           
            if($_SESSION['users']!="0"){
              ?> 
              <a class="nav-link m-btn btn me-2"  href="logout">   خروج</a>
              <?php
            }
            else{
            ?>
              <a class="nav-link m-btn btn me-2"  href="login">   دخول</a>
          <?php } ?>          </li>
        </ul>
      </div>
   </div>
  </nav>