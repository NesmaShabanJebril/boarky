
<?php
session_start();
include('../config.php');
if(isset($_POST['add'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $image_name = addslashes($_FILES['image']['name']);
    $image_up = 'img/'.$image_name;
    $image_location = $_FILES['image']['tmp_name'];
    $result = mysqli_query($con, "SELECT * FROM user where email='$email' or phone='$phone'");
   $i=0;
    while($row = mysqli_fetch_array($result)){
        $i++;
    }
    if($i==0){
$insert = "INSERT INTO user (`name`,`email`,`phone`,`password`,`address`,`img`)
 VALUES ('$name','$email','$phone','$password','$address','$image_up')";
mysqli_query($con , $insert); 
move_uploaded_file($image_location,'../img/'.$image_name);
   $_SESSION['message']='تم تسجيل حسابك  بنجاح';
header('Location: login');
exit;
    }
    else{
        $_SESSION['message']="الايميل او رقم الهاتف موجد بالفعل ";
        header('Location: register');
        exit;
    }
}
?>
<?php 
include "header.php" ?>
<br><br> <br><br> 


  <main style="background:#043c5a">
    <div class="container">

      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

              <div class="card mb-3 ">

                <div class="card-body">

                  <div class="pt-4 pb-2">
                    <h5 class="card-title text-center pb-0 fs-4">سجل حسابك</h5>
                    <p class="text-center small">ادخل البيانات المطلوبة</p>
                  </div>
                  <?php 
	
    if(isset($_SESSION['message'])){
      ?>
      <div class="alert alert-danger text-center">
        <?php echo $_SESSION['message']; ?>
      </div>
      <?php
      unset($_SESSION['message']);
    }

    ?>
              
                  <form class="row g-3 needs-validation" action="register.php" method="post"  enctype="multipart/form-data" novalidate>
                  <div class="col-12">
                      <label  class="form-label"> الاسم بالكامل</label>
                      <input type="text" name="name" class="form-control"  required>
                      <div class="invalid-feedback">من فضلك ادخل  الاسم بالكامل</div>
                    </div>
                    <div class="col-12">
                      <label  class="form-label"> ايميل</label>
                      <input type="email" name="email" class="form-control"  required>
                      <div class="invalid-feedback">من فضلك ادخل  الايميل</div>
                    </div>
                    <div class="col-12">
                      <label  class="form-label"> موبايل</label>
                      <input type="text" name="phone" class="form-control"  required>
                      <div class="invalid-feedback">من فضلك ادخل رقم  الموبايل</div>
                    </div>
                    <div class="col-12">
                      <label  class="form-label">العنوان </label>
                      <input type="text" name="address" class="form-control"  required>
                      <div class="invalid-feedback">من فضلك ادخل  العنوان</div>
                    </div>
                    <div class="col-12">
                      <label  class="form-label">كلمة المرور</label>
                      <input type="password" name="password" class="form-control" id="yourPassword" required>
                      <div class="invalid-feedback">من فضلك ادخل كلمة المرور</div>
                    </div>
                    <div class="col-12">
                  <label  class="form-label">الصورة</label>    
                    <input class="form-control" type="file"  name="image">
                </div>
                    <div class="col-12">
                     <p> لديك حساب بالفعل <a href="login.php">
                        دخول  
            </a> </p>
                </div>
                    
                    <div class="col-12">
                      <button class="btn m-btn w-100" type="submit" name="add">تسجيل</button>
                    </div>
                  
                  </form>

                </div>
</div>

            </div>
          </div>
        </div>

      </section>

    </div>
  </main><!-- End #main -->


<?php include "footer.php" ?>
