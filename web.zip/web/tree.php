<?php
session_start();
if($_SESSION['users']){
$tree="active";
include "header.php" ?>
<br><br> <br><br> 
<div class="container my-5">
        <br><br>
        <h1>
           شجرة عائلة بوعركي
        </h1>
        <br><br>
        <?php
        include('../config.php');
        $result = mysqli_query($con, "SELECT * FROM tree");
       while($row = mysqli_fetch_array($result)){
        echo "
        <a href='http://localhost/buarki/$row[img]' target='_blank'> <img src='../$row[img]' class='w-100'></a>
        <br><br>";
       }
        ?>
        <br><br>

       <br><br> 
 </div>
 <?php include "footer.php" ;
 }
 else{
   $_SESSION['users']="0";
  header('location: login.php');
            $_SESSION['message']="تسجيل دخول ";
            die; 
 }
  ?>