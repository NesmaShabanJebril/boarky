<?php
 session_start();
include('../config.php');
if(isset($_POST['login'])){
     
    $email = $_POST["email"];
    $password = $_POST["password"];
    $result =mysqli_query($con,"SELECT * FROM user where  email ='$email' and `password`='$password'");
      $i=0;
    while($user = mysqli_fetch_array($result)){
       $id=$user['id'];  
        $i++;
    }
    if($i==0){
        header('location: login');
            $_SESSION['message']="الايميل وكلمة المرور خطأ  ";
            die;  
    }
    else{
        $result1 =mysqli_query($con,"SELECT * FROM user where  email ='$email' and `password`='$password' and status='1'");
        $user1 = mysqli_fetch_array($result1);
        if($user1==""){
            header('location: login');
            $_SESSION['message']="انتظر حتي يتم الموافقه علي حسابك ";
            die;    
        }
        else{
        $_SESSION['users'] = $id;
        header('location: ../index');
    }}

}
   

 
?>
<?php 
include "header.php" ?>
<br><br> <br><br> 


  <main style="background:#043c5a">
    <div class="container">

      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

              <div class="card mb-3 ">

                <div class="card-body">

                  <div class="pt-4 pb-2">
                    <h5 class="card-title text-center pb-0 fs-4">ادخل حسابك</h5>
                    <p class="text-center small">ادخل الايميل وكلمة المرور</p>
                  </div>

                  <?php 
	
                if(isset($_SESSION['message'])){
                  ?>
                  <div class="alert alert-danger text-center">
                    <?php echo $_SESSION['message']; ?>
                  </div>
                  <?php
                  unset($_SESSION['message']);
                }

                ?>
                  <form class="row g-3 needs-validation" action="login.php" method="post"  novalidate>

                    <div class="col-12">
                      <label for="email" class="form-label">ايميل</label>
                      <div class="input-group has-validation">
                        <span class="input-group-text m-btn rounded-0 rounded-end" id="inputGroupPrepend">@</span>
                        <input type="text" name="email" class=" rounded-0 rounded-start form-control" id="email" required>
                        <div class="invalid-feedback">من فضلك ادخل الايميل</div>
                      </div>
                    </div>

                    <div class="col-12">
                      <label for="yourPassword" class="form-label">كلمة المرور</label>
                      <input type="password" name="password" class="form-control" id="yourPassword" required>
                      <div class="invalid-feedback">من فضلك ادخل كلمة المرور</div>
                    </div>
                    <div class="col-12">
                     <p> ليس لديك حساب <a href="register.php">
                         تسجيل حساب جديد
            </a> </p>
                </div>
                    
                    <div class="col-12">
                      <button class="btn m-btn w-100" type="submit" name="login">تسجيل</button>
                    </div>
                  
                  </form>

                </div>
</div>

            </div>
          </div>
        </div>

      </section>

    </div>
  </main><!-- End #main -->


<?php include "footer.php" ?>
