<?php
session_start();
include('../config.php');
if(isset($_POST['send'])){


         $mail1 = mysqli_query($con, "SELECT * FROM contact");
      $mail = mysqli_fetch_array($mail1);
    $from= $_POST["email"] ;
       
       $to = $mail['gmail'];
$subject = $_POST["name"]." ".$_POST["phone"];
$txt =  $_POST["message"];
$headers = "From: $from" . "\r\n" .
"CC:  $to";

mail($to,$subject,$txt,$headers);
            $_SESSION['message']="  تم ارسال الرسالة بنجاح  ";
            header('location: contact_us');
            die;    
  
}
   

 
?>
<?php


$contact="active";
include "header.php" ?>

<main style="background:#043c5a">
    <div class="container">
    <br><br><br><br>
      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class=" col-md-8 d-flex flex-column align-items-center justify-content-center">

              <div class="card mb-3 w-100">
             
                <div class="card-body">
                          <?php 
	
                if(isset($_SESSION['message'])){
                  ?>
                  <div class="alert alert-success text-center">
                    <?php echo $_SESSION['message']; ?>
                  </div>
                  <?php
                  unset($_SESSION['message']);
                }

                ?>
        <h1>
          تواصل معانا من خلال
        </h1>
        <br><br>
        <?php
        include('../config.php');
        $result = mysqli_query($con, "SELECT * FROM contact");
       while($row = mysqli_fetch_array($result)){
    echo "
      <h6>
            <a href='tel:$row[phone]' class='m-2' title='phone' target='_blank'><i class='fa-solid fa-phone mx-3'></i> $row[phone]</a><br><br>
            <a href='https://wa.me/$row[whatsapp]' class='m-2' title='whatsapp'  target='_blank'><i class='fa-brands fa-whatsapp mx-3'></i> $row[whatsapp]</a><br><br>
            <a href='mailto:$row[gmail]' class='m-2' title='gmail'  target='_blank'><i class='fa-solid fa-at mx-3'></i> $row[gmail]</a><br><br>
       
   </h6> ";
   
        
  }
  ?>
        <br><br>
         <h1>
          او من خلال ارسال رسالة لنا
        </h1>
              
                  <form class="row g-3 needs-validation" action="contact_us.php" method="post"  novalidate>
                      <div class="col-12">
                      <label for="yourPassword" class="form-label"> الاسم</label>
                      <input type="text" name="name" class="form-control"  required>
                      <div class="invalid-feedback">من فضلك ادخل الاسم</div>
                    </div>
                     <div class="col-12">
                      <label for="yourPassword" class="form-label"> رقم الهاتف</label>
                      <input type="text" name="phone" class="form-control"  required>
                      <div class="invalid-feedback">من فضلك ادخل  رقم الهاتف</div>
                    </div>
                    <div class="col-12">
                      <label for="email" class="form-label">ايميل</label>
                      <div class="input-group has-validation">
                        <span class="input-group-text m-btn rounded-0 rounded-end" id="inputGroupPrepend">@</span>
                        <input type="text" name="email" class=" rounded-0 rounded-start form-control" id="email" required>
                        <div class="invalid-feedback">من فضلك ادخل الايميل</div>
                      </div>
                    </div>
                     
                    
                    <div class="col-12">
                      <label for="yourPassword" class="form-label"> الرسالة</label>
                      <textarea  name="message" class="form-control"  required></textarea>
                      <div class="invalid-feedback">من فضلك ادخل  رسالتك</div>
                    </div>
                 
                    
                    <div class="col-12">
                      <button class="btn m-btn w-100" type="submit" name="send">تسجيل</button>
                    </div>
                  
                  </form>
        </div></div>
       <br><br> 
 </div> </div> </div></section></main>
<?php
include "footer.php"
?>