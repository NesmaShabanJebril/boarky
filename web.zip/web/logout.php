<?php
session_start();
$_SESSION['users']="0";
header('location: ../index');
?>
