<footer class="shadow p-3 text-center bg-body">
   <h2>
   <?php
        include('../config.php');
        $result = mysqli_query($con, "SELECT * FROM contact");
       while($row = mysqli_fetch_array($result)){
    echo "
      
            <a href='tel:$row[phone]' class='m-2' title='phone'><i class='fa-solid fa-phone'></i></a>
            <a href='$row[gmail]' class='m-2' title='gmail'><i class='fa-solid fa-at'></i></a>
    <a href='https://wa.me/$row[whatsapp]' class='m-2' title='whatsapp'><i class='fa-brands fa-whatsapp'></i></a>
    ";
  }

        $result1 = mysqli_query($con, "SELECT * FROM social");
       while($row1 = mysqli_fetch_array($result1)){
    echo "
    <a href='$row1[link]' class='m-2' ><i class='fa-brands fa-$row1[name]'></i></a>
    ";
  }
  ?>

   </h2>
  </footer>
  
</body>
</html>