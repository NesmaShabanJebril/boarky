<?php 
session_start();
$about="active";
include "header.php" ?>
<br><br> <br><br> 
<div class="container my-5">
    <div class="row">
      <div class="col-md-6">
        <br><br>
        <h1>
          نبذه عن عائلة بوعركي
        </h1>
        <br><br>
        <?php
        include('../config.php');
        $result = mysqli_query($con, "SELECT * FROM about");
       while($row = mysqli_fetch_array($result)){
        echo "
        <p>
        $row[about]
        </p>
        <br><br>";
       }
        ?>
        <br><br>
      
      </div>
      <div class="col-md-6">
        <img src="../img/logo.jpg" class="w-100 ">
      </div>
    </div>
  </div><br><br> 

<?php include "footer.php" ?>
