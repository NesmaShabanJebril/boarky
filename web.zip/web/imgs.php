<?php 
$id=$_GET['id'];
?>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>موقع عائلة بوعركي</title> 
  <link rel="stylesheet" href="../css/all.min.css">
  <script src="../js/all.min.js"></script>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery-3.7.1.min.js"></script>
  <script src="../js/main.js"></script>
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/media.css">
 
</head>
<body class="text-center" style="background:#000">
<div class="container ">
    <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
    <div class="carousel-inner">
        <?php
         include('../config.php');
    $result = mysqli_query($con, "SELECT * FROM gallary where id='$id'");
       while($row = mysqli_fetch_array($result)){
        echo "
       
      <div class='carousel-item active text-center'>
        <img  src='../$row[img]' class=''>
      </div>
      ";}
      $result1 = mysqli_query($con, "SELECT * FROM gallary");
      while($row1= mysqli_fetch_array($result1)){
        echo "
       
        <div class='carousel-item text-center'>
          <img  src='../$row1[img]' class=' '>
        </div>
        ";}
      ?>
      
   
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
      