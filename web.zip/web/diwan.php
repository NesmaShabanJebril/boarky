<?php 
session_start();
$diwan="active";
include "header.php" ?>
<br><br> <br><br> 
<div class="container my-5">
   
        <br><br>
        <h1>
           دواوين عائلة بوعركي
        </h1>
        <br><br>
        <div class="table-responsive">
  <table class="table align-middle shadow">
    <thead>
      <tr >
        <th style="background:#043c5a!important;color:#fff">المنطقة</th>
        <th style="background:#043c5a!important;color:#fff">العنوان</th>
        <th style="background:#043c5a!important;color:#fff">المسئول</th>
        <th style="background:#043c5a!important;color:#fff">رقم الهاتف</th>
        <th style="background:#043c5a!important;color:#fff">التوقيت</th>
        <th style="background:#043c5a!important;color:#fff">الموقع علي الخريطه</th>
      </tr>
    </thead>
    <tbody>
        <?php
        include('../config.php');
        $result = mysqli_query($con, "SELECT * FROM diwan");
       while($row = mysqli_fetch_array($result)){
        echo "
        <tr>
        <td class='py-5'> $row[city]</td>
        <td> $row[address]</td>
        <td> $row[owner]</td>
        <td> $row[phone]</td>
        <td> $row[time]</td>
       <td> <a href='$row[location]' target='_blank' class='btn m-btn'>الموقع علي الخريطة</a></td>
      </tr>
      ";
       }
        ?>
     
    </tbody>
  </table>
</div>

        <br><br>
      
      </div>
      
    </div>
  </div><br><br> 

<?php include "footer.php" ?>
