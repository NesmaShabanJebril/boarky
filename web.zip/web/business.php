<?php 
session_start();
$business="active";
include "header.php" ?>
<br><br> <br><br> 
<div class="container my-5">
   
        <br><br>
        <h1>
         الدليل التجاري
        </h1>
        <br><br>
        <div class="row">
      
        <?php
        include('../config.php');
        $result = mysqli_query($con, "SELECT * FROM business");
       while($row = mysqli_fetch_array($result)){
        echo "
        <div class='col-md-3 col-sm-6'>
        <div class='card '>
        <div class='card-body'>
       <h2> $row[name]</h2>
        <p>
        $row[type]
        </p>
        <p>
        $row[address]
        </p>
        <p>
        $row[phone]
        </p>
        </div></div> <br><br></div>
       
        
        ";
        
       }
        ?>
        <br><br>
      
     
     
    </div>
  </div><br><br> 

<?php include "footer.php" ?>
