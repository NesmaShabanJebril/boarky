<?php
session_start();
if($_SESSION['users']){
$gallary="active";
include "header.php" ?>
<br><br> <br><br> 
<div class="container my-5">
        <br><br>
        <h1>
           معرض صور عائلة بوعركي
        </h1>
        <br><br>
        <div class="row">
        <?php
        include('../config.php');
        $result = mysqli_query($con, "SELECT * FROM gallary");
       while($row = mysqli_fetch_array($result)){
        echo "
        <div class='col-md-3 col-sm-6 text-center'>
        <a class='card my-5' href='$row[link]' target='_blank'>  <img src='../$row[img]' class='card-img-top'>
        <br> <h5>$row[name]</h5><br>
        <p>$row[details]</p>
        </a>
        </div>
        <br><br>";
       }
        ?>
        </div>
        <br><br>

       <br><br> 
 </div>
 <?php include "footer.php" ;
 }
 else{
   $_SESSION['users']="0";
  header('location: login.php');
            $_SESSION['message']="تسجيل دخول ";
            die; 
 }
  ?>